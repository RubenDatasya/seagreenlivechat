//
//  CameraPosition.swift
//  SeagreenLiveChat
//
//  Created by Ruben Mimoun on 03/05/2023.
//

import Foundation

enum CameraPosition {
    case rear
    case front
}
